const express = require('express');
const cors = require('cors');
const path = require('path');
const mongoose = require('mongoose');
const app = express();

// Update CORS configuration
app.use(cors());

app.use(express.json());
app.use(express.static(path.join(__dirname, 'subject00-public')));

// MongoDB connection with error handling
mongoose.connect('mongodb://localhost:27017/timetableGenerator', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Connected to MongoDB for Subjects');
}).catch(err => {
    console.error('MongoDB connection error:', err);
    process.exit(1); // Exit if cannot connect to database
});

const SubjectSchema = new mongoose.Schema({
    name: { 
        type: String, 
        required: true
    },
    description: { 
        type: String, 
        required: true 
    },
    iconClass: { 
        type: String, 
        default: 'ri-book-line' 
    },
    buttonColor: { 
        type: String, 
        default: 'blue' 
    },
    createdAt: { 
        type: Date, 
        default: Date.now 
    }
});

const Subject = mongoose.model('Subject', SubjectSchema);

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'subjects-public', 'subjects.html'));
});

// Simplified subject creation route (no auth)
app.post('/api/subjects', async (req, res) => {
    try {
        console.log('Received subject creation request:', req.body);

        const { name, description, iconClass, buttonColor } = req.body;
        
        // Validate required fields
        if (!name || !description) {
            return res.status(400).send({ 
                error: 'Name and description are required fields' 
            });
        }

        const subject = new Subject({
            name,
            description,
            iconClass: iconClass || 'ri-book-line',
            buttonColor: buttonColor || 'blue'
        });

        console.log('Attempting to save subject:', subject);

        const savedSubject = await subject.save();
        console.log('Subject saved successfully:', savedSubject);
        
        res.status(201).send(savedSubject);
    } catch (error) {
        console.error('Error creating subject:', error);
        res.status(400).send({ error: error.message });
    }
});

// Get all subjects (no auth)
app.get('/api/subjects', async (req, res) => {
    try {
        const subjects = await Subject.find({});
        console.log('Found subjects:', subjects);
        res.send(subjects);
    } catch (error) {
        console.error('Error fetching subjects:', error);
        res.status(500).send({ error: error.message });
    }
});

// Delete subject (no auth)
app.delete('/api/subjects/:id', async (req, res) => {
    try {
        const subject = await Subject.findByIdAndDelete(req.params.id);
        if (!subject) {
            return res.status(404).send({ error: 'Subject not found' });
        }
        res.send(subject);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

app.listen(3000, () => {
    console.log('Subjects server running on port 3000');
});