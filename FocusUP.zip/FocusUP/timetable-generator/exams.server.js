const express = require('express');
const cors = require('cors');
const path = require('path');
const mongoose = require('mongoose');
const app = express();

// Middleware setup
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'subjects-public')));

// MongoDB connection with error handling
mongoose.connect('mongodb://localhost:27017/timetableGenerator', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Connected to MongoDB for Exams');
}).catch(err => {
    console.error('MongoDB connection error:', err);
    process.exit(1); // Exit if cannot connect to database
});

// Exam Schema definition
const ExamSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    iconClass: {
        type: String,
        default: 'ri-book-line'
    },
    iconColor: {
        type: String,
        default: 'indigo-600'
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

const Exam = mongoose.model('Exam', ExamSchema);

// Home route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'subjects-public', 'exams.html'));
});

// Create a new exam
app.post('/api/exams', async (req, res) => {
    try {
        console.log('Received exam creation request:', req.body);
        
        const { name, description, iconClass, iconColor } = req.body;
        
        // Validate required fields
        if (!name || !description) {
            return res.status(400).send({
                error: 'Name and description are required fields'
            });
        }
        
        const exam = new Exam({
            name,
            description,
            iconClass: iconClass || 'ri-book-line',
            iconColor: iconColor || 'indigo-600'
        });
        
        console.log('Attempting to save exam:', exam);
        
        const savedExam = await exam.save();
        console.log('Exam saved successfully:', savedExam);
        
        res.status(201).send(savedExam);
    } catch (error) {
        console.error('Error creating exam:', error);
        res.status(400).send({ error: error.message });
    }
});

// Get all exams
app.get('/api/exams', async (req, res) => {
    try {
        const exams = await Exam.find({});
        console.log('Found exams:', exams);
        res.send(exams);
    } catch (error) {
        console.error('Error fetching exams:', error);
        res.status(500).send({ error: error.message });
    }
});

// Delete an exam
app.delete('/api/exams/:id', async (req, res) => {
    try {
        const exam = await Exam.findByIdAndDelete(req.params.id);
        if (!exam) {
            return res.status(404).send({ error: 'Exam not found' });
        }
        res.send(exam);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// Server initialization
const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
    console.log(`Exams server running on port ${PORT}`);
});